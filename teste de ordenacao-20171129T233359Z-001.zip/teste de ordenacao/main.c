#include "bubblesort.h"
#include "selectionsort.h"
#include "insertionsort.h"
#include "shellsort.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

void imprimeVetor(int vetor[], int tam) {
    int j=0;
    for (j=0; j<tam; j++)
        printf("%d ", vetor[j]);
}

void main() {
    int* qcont;
    int* qcont_2;
    int* qcont_3;
    int* qcont_4;
    int* qcont_5;

    qcont=(int*)calloc(4,sizeof(int));
    qcont_2=(int*)calloc(4,sizeof(int));
    qcont_3=(int*)calloc(4,sizeof(int));
    qcont_4=(int*)calloc(4,sizeof(int));

    int vetor[] = {10, 90, 5, 33, 28, 51, 46, 2, 11, 587, 11};
    int vetor_2[] = {234, 132, 34, 12, 11, 9, 6, 4, 3, 2, 1};
    int vetor_3[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    int vetor_4[] = {4, 2, 5, 8, 6, 12, 10, 9, 14, 15, 17};

    int tam = 11;
    printf("BUBBLE\n");
    qcont[0] = bubblesort_1(vetor, tam);
    imprimeVetor(vetor, tam);
    printf(" # %d\n",qcont[0]);
    
    qcont[1] = bubblesort_1(vetor_2, tam);
    imprimeVetor(vetor_2, tam);
    printf(" # %d\n",qcont[1]);

    qcont[2] = bubblesort_1(vetor_3, tam);
    imprimeVetor(vetor_3, tam);
    printf("  # %d\n",qcont[2]);
    
    qcont[3] = bubblesort_1(vetor_4, tam);
    imprimeVetor(vetor_4, tam);
    printf("  # %d\n",qcont[3]);

    printf("----------------------------------------\n");  
		
    printf("SELECTION\n");
    qcont_2[0] = selectionsort(vetor, tam);
    imprimeVetor(vetor, tam);
    printf(" # %d\n",qcont_2[0]);
    
    qcont_2[1] = selectionsort(vetor_2, tam);
    imprimeVetor(vetor_2, tam);
    printf(" # %d\n",qcont_2[0]);

    qcont_2[2] = selectionsort(vetor_3, tam);
    imprimeVetor(vetor_3, tam);
    printf("  # %d\n",qcont_2[0]);
    
    qcont_2[3] = selectionsort(vetor_4, tam);
    imprimeVetor(vetor_4, tam);
    printf("  # %d\n",qcont_2[0]);

    printf("----------------------------------------\n");
    
	
    printf("INSERTION\n");
    qcont_3[0] = insertionsort(vetor, tam);
    imprimeVetor(vetor, tam);
    printf(" # %d\n",qcont_3[0]);
    
    qcont_3[1] = insertionsort(vetor_2, tam);
    imprimeVetor(vetor_2, tam);
    printf(" # %d\n",qcont_3[1]);

    qcont_3[2] = insertionsort(vetor_3, tam);
    imprimeVetor(vetor_3, tam);
    printf("  # %d\n",qcont_3[2]);
    
    qcont_3[3] = insertionsort(vetor_4, tam);
    imprimeVetor(vetor_4, tam);
    printf("  # %d\n",qcont_3[3]);

    printf("----------------------------------------\n");
    
	
    printf("SHELL\n");
    qcont_4[0] = shellsort_1(vetor, tam);
    imprimeVetor(vetor, tam);
    printf(" # %d\n",qcont_4[0]);
    
    qcont_4[1] = shellsort_1(vetor_2, tam);
    imprimeVetor(vetor_2, tam);
    printf(" # %d\n",qcont_4[1]);

    qcont_4[2] = shellsort_1(vetor_3, tam);
    imprimeVetor(vetor_3, tam);
    printf("  # %d\n",qcont_4[2]);
    
    qcont_4[3] = shellsort_1(vetor_4, tam);
    imprimeVetor(vetor_4, tam);
    printf("  # %d\n",qcont_4[3]);

    printf("----------------------------------------\n");
}






