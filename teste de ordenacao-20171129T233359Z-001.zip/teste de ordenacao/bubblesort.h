#include <stdio.h>
#include <stdlib.h>

int bubblesort(int *vetor, int tamanho) {
    int aux, i, j;
    for (i=0; i<tamanho; i++){
        for (j=0; j<tamanho-1; j++){
            if (vetor[j] > vetor[j+1]) {
                aux = vetor[j];
                vetor[j] = vetor[j+1];
                vetor[j+1] = aux;
            }
        }
    }
}

int bubblesort_1(int *vetor, int tamanho) {
    int n = tamanho;
    int aux, i,cont=0;
    int esta_ordenado = 1;
    for (n=tamanho; n > 1; n--) {
        esta_ordenado = 1;
        for (i=0; i < n-1; i++){
	cont++;
            if (vetor[i] > vetor[i+1]){
                aux = vetor[i];
                vetor[i] = vetor[i+1];
                vetor[i+1] = aux;
                esta_ordenado = 0;
            }
        }
        if (esta_ordenado == 1) {
            return;
        }
    }
return cont;
}
