#include <stdio.h>
#include <stdlib.h>
int troca(int* v,int i,int j){
    int aux;
    aux =v[i];
    v[i] = v[j];
    v[j] = aux;
    return 1;
}

int bubblesort_1(int *vetor, int tamanho) {
    int n = tamanho;
    int aux, i,cont=0;
    int esta_ordenado = 1;
    for (n=tamanho; n > 1; n--) {
        esta_ordenado = 1;
        for (i=0; i < n-1; i++){
	cont++;
            if (vetor[i] > vetor[i+1]){
                aux = vetor[i];
                vetor[i] = vetor[i+1];
                vetor[i+1] = aux;
                esta_ordenado = 0;
            }
        }
        if (esta_ordenado == 1) {
            return;
        }
    }
return cont;
}

int bubblesort_2(int *vetor, int tamanho) {
    int n = tamanho;
    int aux, i,j,cont=0;
    int flag;
    for (i=0;i<n-1;i++){
        flag=0;
        if(i%2==0){
            for (j=0; j < n; j++){
                cont++;
                if (vetor[j] > vetor[j+1]){
                    aux = vetor[j];
                    vetor[j] = vetor[j+1];
                    vetor[j+1] = aux;
                    flag = 1;
                }
            }
        }    
        else if(i%2!=0){
            for (j=n; j >= 0; j--){
                cont++;
                if (vetor[j] < vetor[j-1]){
                    aux = vetor[j];
                    vetor[j] = vetor[j-1];
                    vetor[j-1] = aux;
                    flag = 1;
                }
            }
        }
        if (flag == 0) {
            return;
        }    
    }
return cont;
}