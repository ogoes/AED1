#include "bubblesort.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

void imprimeVetor(int vetor[], int tam) {
    int j=0;
    for (j=0; j<tam; j++)
        printf("%d ", vetor[j]);
}

void main() {
    int* qcont;
    int* qcont_2;

    qcont=(int*)calloc(4,sizeof(int));
    qcont_2=(int*)calloc(4,sizeof(int));

    int vetor[] = {10, 90, 5, 33, 28, 51, 46, 2, 11, 587, 11};
    int vetor_2[] = {234, 132, 34, 12, 11, 9, 6, 4, 3, 2, 1};
    int vetor_3[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    int vetor_4[] = {4, 2, 5, 8, 6, 12, 10, 9, 14, 15, 17};

    int tam = 11;
    printf("BUBBLE\n");
    qcont[0] = bubblesort_1(vetor, tam);
    imprimeVetor(vetor, tam);
    printf(" # %d\n",qcont[0]);
    
    qcont[1] = bubblesort_1(vetor_2, tam);
    imprimeVetor(vetor_2, tam);
    printf(" # %d\n",qcont[1]);

    qcont[2] = bubblesort_1(vetor_3, tam);
    imprimeVetor(vetor_3, tam);
    printf("  # %d\n",qcont[2]);
    
    qcont[3] = bubblesort_1(vetor_4, tam);
    imprimeVetor(vetor_4, tam);
    printf("  # %d\n",qcont[3]);

    printf("----------------------------------------\n");  
		
    printf("BUBBLE KNUTH\n");
    qcont_2[0] = bubblesort_2(vetor, tam);
    imprimeVetor(vetor, tam);
    printf(" # %d\n",qcont_2[0]);
    
    qcont_2[1] = bubblesort_2(vetor_2, tam);
    imprimeVetor(vetor_2, tam);
    printf(" # %d\n",qcont_2[1]);

    qcont_2[2] = bubblesort_2(vetor_3, tam);
    imprimeVetor(vetor_3, tam);
    printf("  # %d\n",qcont_2[2]);
    
    qcont_2[3] = bubblesort_2(vetor_4, tam);
    imprimeVetor(vetor_4, tam);
    printf("  # %d\n",qcont_2[3]);

    printf("----------------------------------------\n");
}






