int insertionsort(int *vetor, int tam) {
    int i, j, aux,cont=0;
    for (i = 1; i < tam; i++) {
        aux = vetor[i];
        j = i;
        while ((cont++>=0&&aux < vetor[j - 1]) && (j > 0)){
            vetor[j] = vetor[j - 1];
            j--;
        }
        vetor[j] = aux;
    }
return cont;
}
