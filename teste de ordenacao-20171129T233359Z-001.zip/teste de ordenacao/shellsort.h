
int shellsort_1(int *vetor, int tamanho) {
    int k , i, aux, j,cont=0;

    for(k = 1; k < tamanho; k = 3*k+1); /* s� para calcular o k */
    // k = tamanho/2;

    while (k > 0) {
        for (i = k; i < tamanho; i++) {
            aux = vetor[i];
            j = i;
            /* efetua compara��es entre elementos com dist�ncia k: */
            while ((cont++>=0) && (vetor[j-k]>aux) && (j>=k)) {
                vetor[j] = vetor[j - k];
                j = j-k;
            }
            vetor[j] = aux;

        }
        k = (k-1)/3; /* atualiza o valor de k. */
        //k = k/2;
    }
return cont;
}
