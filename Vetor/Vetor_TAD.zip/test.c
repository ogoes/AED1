#include "Vetor.h"

void main(){
	// Vetor *V = Cria_vetor();
	// Inicializa_vetor(V, 10, 5);
	// Insere_fim_vetor(V, 2);
	// Imprime_vetor(V);
	// Ordena_cres_vetor(V);
	// Ordena_decre_vetor(V);
	// Atualiza_vetor(V, 3, 7);
	// Insere_espec_vetor(V, 2, 5);
	// Remove_vetor(V, 1, 10);
	// int a = Procura_vetor(V, 2);
}






